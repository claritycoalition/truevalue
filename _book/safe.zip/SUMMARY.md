# Summary

* [True Value Overview](README.md)
* [True Value Initiative](tvinitiative.md)
* [Clarity Projects](clarityprojects.md)
* [Ecochefs](ecochefs.md)
* [Super Smart Water Investing](super-smart-water-investing.md)
* [Sub-Sahara Food and Nutrition Security](sub-sahara-food-and-energy-security.md)
* [India's Development Alternatives](indias-development-alternatives.md)
* [TV Blockchain](tv-blockchain.md)
* [TV Semantics](tv-semantics.md)
* 


