# Clarity Tools and Innovations

Clarity has developed a number of tools and innovations in support of the True Value Initiative.

* True Value Accounting
  * Resource Accounting
  * Confidence Accounting
* Policy Performance Bonds
* TV Semantics Framework
* CODVERB
* Good, Green, Fair score



